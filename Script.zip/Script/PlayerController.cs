﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float speedX;
    public float jumpSpeedY;
    float speed;

    private int count = 0;
    private int score = 0;
    private int live = 3;
    private int wincount = 0;
    private int live2 = 3;

    public Text countText;
    public Text WinText;
    public Text scoreText;
    public Text LiveText;
    public Text LoseText;
    public Text LiveText2;

    bool facingRight = true;
    bool jumping;
    public bool isActive;

    private Animator anim;
    private Rigidbody2D rb;

    public AudioSource musicSource;
    public AudioClip musicClipOne;
    public AudioClip musicClipTwo;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        facingRight = true;
        SetCountText();
        SetScoreText();
        SetLiveTest();
        WinText.text = "";
        LoseText.text = "";
        LiveText2.text = "";
        musicSource.clip = musicClipOne;
        musicSource.Play();
    }

    // Update is called once per frame
    void Update()
    {
        MovePlayer(speed);

        if (Input.GetKeyDown(KeyCode.A))
        {
            speed = -speedX;
        }
        if (Input.GetKeyUp(KeyCode.A))
        {
            speed = 0;
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            speed = speedX;
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            speed = 0;
        }
        // jump-idel
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumping = true;
            rb.AddForce(new Vector2(rb.velocity.x, jumpSpeedY));
            anim.SetInteger("States", 2);

        }

    }
    void MovePlayer(float playerSpeed)
    {
        if (playerSpeed < 0 && !jumping || playerSpeed > 0 && !jumping)
        {
            anim.SetInteger("States", 3);
        }
        if (playerSpeed == 0 && !jumping)
        {
            anim.SetInteger("States", 0);
        }
        rb.velocity = new Vector3(speed, rb.velocity.y, 0);
    }
    void Flip()
    {
        if (speed > 0 && !facingRight || speed < 0 && !facingRight)
        {
            facingRight = !facingRight;
            Vector2 temp = transform.localScale;
            temp.x = temp.x * -1;
            transform.localScale = temp;
        }
    }
    void FixedUpdate()
    {
        if (live == 0)
        {
            LoseText.text = "You Lost!";
            Destroy(this.gameObject);
        }
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }

        float moveHorizontal = Input.GetAxis("Horizontal");

        Vector2 movement = new Vector2(moveHorizontal, 0);

        rb.AddForce(movement * speed);

        rb.velocity = new Vector2(moveHorizontal * speed, rb.velocity.y);
    }
    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.tag == "Ground")
        {
            jumping = false;
            anim.SetInteger("States", 0);
        }
        if (other.gameObject.CompareTag("Pickups"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            wincount = wincount + 1;
            score = score + 1;
            SetCountText();
            SetScoreText();
        }
        if (other.gameObject.CompareTag("Enemies"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            score = score - 1;
            live = live - 1;
            SetCountText();
            SetScoreText();
            SetLiveTest();
        }
        if (other.gameObject.CompareTag("Pickups2"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            wincount = wincount + 1;
            score = score + 1;
            SetCountText();
            SetScoreText();
        }
        if (other.gameObject.CompareTag("Enemies2"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            score = score - 1;
            live2 = live2 - 1;
            SetCountText();
            SetScoreText();
            SetLiveTest2();
        }
        if (wincount == 5)
        { 
            transform.position = new Vector3(52f, -2.05f, 0);

        }
    }
    void SetCountText()
    {
        countText.text = "Count: " + count.ToString();
    }
    void SetScoreText()
    {
        scoreText.text = "Score: " + score.ToString();
        if (wincount == 5)
        { 
            WinText.text = "HORRAY! WON!";
            musicSource.Stop();
            musicSource.clip = musicClipTwo;
            musicSource.Play();
        }

    }
    void SetLiveTest()
    {
        LiveText.text = "Live:" + live.ToString();
    }
    void SetLiveTest2()
    {
        LiveText2.text = "Live:" + live2.ToString();
    }

}
