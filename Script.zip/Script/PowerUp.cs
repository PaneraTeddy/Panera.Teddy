﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    // public GameObject pickupEffect;
    public float multiplier;
    public float duration = 4f;
   // public bool powerupActive = false;


    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Boundary") || other.CompareTag("Enemy") || other.CompareTag("PowerUp"))
        {
            return;
        }
        if (other.CompareTag("Player"))
        {
            other.GetComponent<PlayerController>().StartCoroutine(Pickups(other));

            // if (powerupActive == true)
            // {
                // other.GetComponent<PlayerController>().StopCoroutine(Pickups(other));
            // }
        }
    }

    IEnumerator Pickups(Collider player)
    {
        // Instantiate(pickupEffect, transform.position, transform.rotation);
        gameObject.SetActive(false);
        PlayerController rate = player.GetComponent<PlayerController>();
        rate.fireRate = 0.06f;
        // powerupActive = true;
        yield return new WaitForSeconds(duration);
        rate.fireRate = 0.25f;
        Destroy(gameObject);
    }
}

