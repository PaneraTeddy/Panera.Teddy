﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class HardModeGameController : MonoBehaviour
{
    public GameObject[] h_hazards;
    public GameObject h_powerUp;

    public Vector3 h_spawnValues;


    public int h_powerUpCount;
    public int h_hazardCount;
    public float h_spawnWait;
    public float h_startWait;
    public float h_waveWait;

    public Text h_ScoreText;
    public Text h_restartText;
    public Text h_gameoverText;
    public Text h_winText;
    public Text h_mainmenu;
    public Text Timer;

    private int h_score;
    private float h_timeLeft = 30.0f;
    private bool h_gameOver;
    private bool h_restart;

    public AudioSource h_musicSource;
    public AudioClip h_musicClipOne;
    public AudioClip h_musicClipTwo;

    void Start()
    {
        h_gameOver = false;
        h_restart = false;
        h_gameoverText.text = "";
        h_restartText.text = "";
        h_winText.text = "";
        h_mainmenu.text = "M - Menu";
        h_score = 0;
        h_UpdateScore();
        StartCoroutine(h_SpawnWaves());


    }
    void Update()
    {
        h_timeLeft -= Time.deltaTime;
        Timer.text =  "Time Left: " + Mathf.Max(0, Mathf.Round(h_timeLeft))+ "s";
        if (h_restart)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                SceneManager.LoadScene("TimeAttack");
            }
        }

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
        if (Input.GetKeyDown(KeyCode.M))
        {
            SceneManager.LoadScene("Main");
        }

    }


    IEnumerator h_SpawnWaves()
    {
        yield return new WaitForSeconds(h_startWait);
        while (true)
        {
            for (int i = 0; i < h_hazardCount; i++)
            {
                GameObject h_hazard = h_hazards[Random.Range(0, h_hazards.Length)];
                Vector3 h_spawnPosition = new Vector3(Random.Range(-h_spawnValues.x, h_spawnValues.x), h_spawnValues.y, h_spawnValues.z);
                Quaternion h_spawnRotation = Quaternion.identity;
                Instantiate(h_hazard, h_spawnPosition, h_spawnRotation);
                yield return new WaitForSeconds(h_spawnWait);
            }
            for (int j = 0; j < h_powerUpCount; j++)
            {
                Vector3 h_spawnPosition = new Vector3(Random.Range(-h_spawnValues.x, h_spawnValues.x), h_spawnValues.y, h_spawnValues.z);
                Quaternion h_spawnRotation = Quaternion.identity;
                Instantiate(h_powerUp, h_spawnPosition, h_spawnRotation);
                yield return new WaitForSeconds(h_spawnWait);
            }
            yield return new WaitForSeconds(h_waveWait);

            if (h_gameOver)
            {
                h_restartText.text = "Press 'R' for Replay";
                h_restart = true;
                break;
            }
        }
    }

    public void h_AddScore(int newScoreValue)
    {
        h_score += newScoreValue;
        h_UpdateScore();
    }

    void h_UpdateScore()
    {
        h_ScoreText.text = "Point: " + h_score;
        if (h_timeLeft <= 0)
          {
            h_winText.text = "GAME CREATED BY [JIAJIA DONG]";
            h_gameoverText.text = "Game Over";
            h_musicSource.clip = h_musicClipOne;
            h_musicSource.Play();
            h_gameOver = true;
            h_restart = true;
            h_DestroyAll("Enemy");

          }
    }
    public void h_GameOver()
    {
        h_gameoverText.text = "Game Over!!!";
        h_musicSource.clip = h_musicClipTwo;
        h_musicSource.Play();
        h_gameOver = true;
    }

    void h_DestroyAll(string tags)
    {
        GameObject[] h_enemies = GameObject.FindGameObjectsWithTag(tags);
        for (int i = 0; i < h_enemies.Length; i++)
        {
            Destroy(h_enemies[i]);
        }
    }
}
