﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destory : MonoBehaviour
{
    public GameObject explosion;
    public GameObject playerExplosion;
    public int scoreValue;
    public HardModeGameController obj;

    void Start()
    {
        GameObject go = GameObject.FindWithTag("Hard");
        obj = (HardModeGameController)go.GetComponent(typeof(HardModeGameController)); GetComponent<HardModeGameController>();
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Boundary") || other.CompareTag("Enemy") || other.CompareTag("PowerUp"))
        {
            return;
        }

        if (explosion != null)
        {
            Instantiate(explosion, transform.position, transform.rotation);
        }
        if (other.tag == "Player")
        {
            Instantiate(playerExplosion, other.transform.position, other.transform.rotation);
            obj.h_GameOver();
        }
        obj.h_AddScore(scoreValue);
        Destroy(other.gameObject);
        Destroy(gameObject);
    }

}
