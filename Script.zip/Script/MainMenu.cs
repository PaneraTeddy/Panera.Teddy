﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public Text hardmode;
    public Text normalmode;

    // Start is called before the first frame update
    void Start()
    {
        hardmode.text = "H - Time Attack";
        normalmode.text = "F - Normal";

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            SceneManager.LoadScene("Normal");
        }
        if (Input.GetKeyDown(KeyCode.H))
        {
            SceneManager.LoadScene("TimeAttack");
        }
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }

    }
}
